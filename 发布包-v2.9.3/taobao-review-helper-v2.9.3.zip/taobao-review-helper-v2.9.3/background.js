// 淘宝评论助手 - Background Service Worker
// 监听扩展图标点击事件，直接打开侧边栏

chrome.action.onClicked.addListener(async (tab) => {
  try {
    // 获取当前窗口
    const currentWindow = await chrome.windows.getCurrent();

    // 打开侧边栏
    await chrome.sidePanel.open({ windowId: currentWindow.id });

    console.log('✅ 侧边栏已打开');
  } catch (error) {
    console.error('❌ 打开侧边栏失败:', error);

    // 降级方案：如果侧边栏不可用，在新标签页打开
    chrome.tabs.create({ url: chrome.runtime.getURL('sidepanel.html') });
  }
});

// 扩展安装时的初始化
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    console.log('🎉 淘宝评论助手已安装');
  } else if (details.reason === 'update') {
    console.log('✅ 淘宝评论助手已更新到 v2.9.3');
  }
});
