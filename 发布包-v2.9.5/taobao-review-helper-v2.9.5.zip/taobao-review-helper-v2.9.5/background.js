// 淘宝评论助手 - Background Service Worker
// 监听扩展图标点击事件，直接打开侧边栏

console.log('🛒 Background Service Worker 已加载');

// 检查侧边栏 API 是否可用
const hasSidePanelAPI = chrome.sidePanel !== undefined;
console.log('侧边栏 API 可用:', hasSidePanelAPI);

chrome.action.onClicked.addListener(async (tab) => {
  console.log('🖱 扩展图标被点击');

  if (!hasSidePanelAPI) {
    console.error('❌ 侧边栏 API 不可用，使用降级方案');
    chrome.tabs.create({ url: chrome.runtime.getURL('sidepanel.html') });
    return;
  }

  try {
    // 获取当前窗口
    const currentWindow = await chrome.windows.getCurrent();
    console.log('🪟 当前窗口 ID:', currentWindow.id);

    // 打开侧边栏
    await chrome.sidePanel.open({ windowId: currentWindow.id });
    console.log('✅ 侧边栏已打开');
  } catch (error) {
    console.error('❌ 打开侧边栏失败:', error.message);
    console.error('错误详情:', error);

    // 降级方案：如果侧边栏不可用，在新标签页打开
    chrome.tabs.create({ url: chrome.runtime.getURL('sidepanel.html') });
  }
});

// 扩展安装时的初始化
chrome.runtime.onInstalled.addListener((details) => {
  console.log('📦 扩展事件:', details.reason);

  if (details.reason === 'install') {
    console.log('🎉 淘宝评论助手已安装');
  } else if (details.reason === 'update') {
    console.log('✅ 淘宝评论助手已更新到 v2.9.3');
  }

  // 设置侧边栏（如果 API 可用）
  if (chrome.sidePanel) {
    chrome.sidePanel.setOptions({
      enabled: true
    }).then(() => {
      console.log('✅ 侧边栏已启用');
    }).catch((err) => {
      console.warn('⚠️ 设置侧边栏失败:', err);
    });
  }
});
